/**
 * @license
 * Copyright 2022-2026 Matter.js Authors
 * SPDX-License-Identifier: Apache-2.0
 */

/*** THIS FILE WILL BE REGENERATED IF YOU DO NOT REMOVE THIS MESSAGE ***/

export * from "./UserLabelBehavior.js";
export * from "./UserLabelServer.js";
export * from "./UserLabelClient.js";
