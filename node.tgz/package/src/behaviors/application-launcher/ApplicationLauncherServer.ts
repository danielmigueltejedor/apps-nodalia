/**
 * @license
 * Copyright 2022-2026 Matter.js Authors
 * SPDX-License-Identifier: Apache-2.0
 */

/*** THIS FILE WILL BE REGENERATED IF YOU DO NOT REMOVE THIS MESSAGE ***/

import { ApplicationLauncherBehavior } from "./ApplicationLauncherBehavior.js";

/**
 * This is the default server implementation of {@link ApplicationLauncherBehavior}.
 */
export class ApplicationLauncherServer extends ApplicationLauncherBehavior {}
