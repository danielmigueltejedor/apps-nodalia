/**
 * @license
 * Copyright 2022-2026 Matter.js Authors
 * SPDX-License-Identifier: Apache-2.0
 */

/*** THIS FILE WILL BE REGENERATED IF YOU DO NOT REMOVE THIS MESSAGE ***/

import { LaundryDryerControlsBehavior } from "./LaundryDryerControlsBehavior.js";

/**
 * This is the default server implementation of {@link LaundryDryerControlsBehavior}.
 */
export class LaundryDryerControlsServer extends LaundryDryerControlsBehavior {}
